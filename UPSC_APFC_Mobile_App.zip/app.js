/**
 * Background-Proof Focus Timer & Official 9-Section Syllabus Engine for UPSC APFC
 */

const DEFAULT_SYLLABUS = [
  {
    id: 'sec_1_eng', title: 'i. General English', isCore: false,
    topics: [
      { id: 'eng_1', name: 'Workmanlike Use of Words & Vocabulary (Synonyms, Antonyms, One-word Substitution)' },
      { id: 'eng_2', name: 'Grammar Rules, Error Spotting & Sentence Improvement' },
      { id: 'eng_3', name: 'Idioms, Phrases, Ordering of Words & Cloze Composition' },
      { id: 'eng_4', name: 'Reading Comprehension Passages & Contextual Workmanlike English' }
    ]
  },
  {
    id: 'sec_2_hist_cult', title: 'ii. Indian Culture, Heritage and Freedom Movements', isCore: false,
    topics: [
      { id: 'hist_1', name: 'Freedom Struggle: 1857 Revolt, Regional Rebellions & Freedom Chronology' },
      { id: 'hist_2', name: 'INC Phases, Gandhian Era (1857-1947), INA & Prominent Freedom Leaders' },
      { id: 'hist_3', name: 'Labour Movement & Press History (N M Lokhande, Deenbandhu, AITUC-INTUC Chronology)' },
      { id: 'hist_4', name: 'Indian Culture & Heritage: Rock Art, Ajanta Jatakas, Black Pagoda & Temple Architecture' },
      { id: 'hist_5', name: 'Performing Arts, Classical Dances, Natyashastra & Regional Tribal Festivals' },
      { id: 'hist_6', name: 'Ancient & Medieval Dynasties (Vijayanagara, Palas, Chalukyas) & Post-Independence 1946 Assembly' }
    ]
  },
  {
    id: 'sec_3_econ_dev', title: 'iii. Developmental Issues and Present Trends in Indian Economy', isCore: false,
    topics: [
      { id: 'econ_1', name: 'Inflation Concepts (Headline vs Core Inflation, Social Cost, HDI Components)' },
      { id: 'econ_2', name: 'Fiscal Policy, Taxation, Disinvestment vs PPP & Money Bill Provisions' },
      { id: 'econ_3', name: 'Monetary Policy, Banking System, RTGS/NEFT & DFIs (IFCI/ICICI/IDBI vs NaBFID)' },
      { id: 'econ_4', name: 'Micro-economics Theory (Monopolistic Competition vs Perfect Competition)' },
      { id: 'econ_5', name: 'High-Priority Govt Welfare Schemes (MUDRA, POSHAN, NISHTHA, BioE3, StandUp India, SMILE)' },
      { id: 'econ_6', name: 'Constitutional vs Non-Constitutional Bodies (Finance Commission, Election Commission, NCW, IMF Quota)' },
      { id: 'econ_7', name: 'Colonial Economic History (Laissez-faire, Agency Houses, Plantation Ownership)' }
    ]
  },
  {
    id: 'sec_4_polity_gov', title: 'iv. Governance and Constitution of India', isCore: false,
    topics: [
      { id: 'pol_1', name: 'Fundamental Rights (Right to Privacy Art 21, Exploitation & Forced Labour Ban)' },
      { id: 'pol_2', name: 'Labour-Linked DPSP Articles (Art 38, Art 39 Equal Pay, Art 41 Right to Work, Art 42 Maternity, Art 43 Living Wage, Art 43A)' },
      { id: 'pol_3', name: 'Constitutional Amendments (61st Voting Age, 42nd DPSP Primacy, 73rd Panchayati Raj, 106th Women)' },
      { id: 'pol_4', name: 'President/VP, Parliament (Art 107 Ordinary Bills, Art 312 All India Services) & Judiciary' },
      { id: 'pol_5', name: 'Centre-State Relations (7th Schedule Lists, 4th Schedule Seat Allocation, River Disputes)' },
      { id: 'pol_6', name: 'APFC Administrative & Quasi-Judicial Role (Section 7A Dues Inquiry & Civil Court Powers)' },
      { id: 'pol_7', name: 'Local Self-Governance (Art 243ZD District Planning), RTI Act & NAM Principles' }
    ]
  },
  {
    id: 'sec_5_sci_comp', title: 'v. General Science and Basic Knowledge of Computer Applications', isCore: false,
    topics: [
      { id: 'sci_1', name: 'Physics: Optics & Lens Behaviour, Inelastic Collisions, AWACS & Microwave Jamming' },
      { id: 'sci_2', name: 'Chemistry: Photochemical Smog, Fatty Acids/Phenol, Bleaching Powder & Soaps' },
      { id: 'sci_3', name: 'Biology & Agriculture: Eyeball Layers, Prop Roots, Chikungunya Virus, Euglena & Grain Protection' },
      { id: 'comp_1', name: 'Computer Hardware, Storage & Memory Registers (RAM, SSD vs HDD, MAR Register)' },
      { id: 'comp_2', name: 'Programming Languages (FORTRAN/JAVA/Pascal vs C) & Real-Time Operating Systems' },
      { id: 'comp_3', name: 'Networking (OSI Session Layer, IP Address 0-255, Mesh Formula n(n-1)/2) & HTML Comments/Mailto' },
      { id: 'comp_4', name: 'File Formats (MIDI/WAV/MP3) & Modern AI (ChatGPT LLM, GPU Training, SSL Security)' }
    ]
  },
  {
    id: 'sec_6_math_stat', title: 'vi. Elementary Mathematics, Statistics and General Mental Ability', isCore: false,
    topics: [
      { id: 'math_1', name: 'Number System, Divisibility Rules, LCM/HCF & Logarithms' },
      { id: 'math_2', name: 'Ratio-Proportion, Mixtures, Ages & Percentage Formulas' },
      { id: 'math_3', name: 'Profit-Loss, Successive Discount, Time-Speed-Distance & Time-Work Proportional Scaling' },
      { id: 'math_4', name: 'Algebra (Quadratic Roots, AP/GP Series) & Geometry/Mensuration Circle Theorems' },
      { id: 'stat_1', name: 'Statistics: Central Tendency (Mean/Median/Mode) & Measures of Dispersion (Std Dev/Variance)' },
      { id: 'stat_2', name: 'Probability (Dice-sum, Event probability with constraints) & Data Interpretation Tables' },
      { id: 'reason_1', name: 'General Mental Ability: Coding-Decoding, Blood Relations, Seating Arrangement & Syllogism Venn Diagrams' }
    ]
  },
  {
    id: 'sec_7_ir_ll_ss', title: 'vii. Industrial Relations, Labour Codes and Social Security in India', isCore: true,
    topics: [
      { id: 'ir_1', name: 'Industrial Disputes Act 1947 & Sec 2(j)/11A (Strike Sec 2q, Lay-off 50%, Chapter VB 100+ threshold, Grievance Committee)' },
      { id: 'ir_2', name: 'Trade Unions Act 1926 (Min 7 workers, 3-yr tenure, Federation Chronology: AITUC➔INTUC➔HMS➔BMS➔CITU)' },
      { id: 'ir_3', name: 'Factories Act 1948 (Adolescent 14-18 yrs, Welfare Officer 500+ workers, Sec 7A Occupier, 3rd Schedule Diseases)' },
      { id: 'ir_4', name: 'The 4 New Labour Codes 2020 (Wages 2019, IR Code 2020 300-worker threshold, Social Security 2020 Gig workers, OSHWC Code 2020)' },
      { id: 'ss_1', name: 'EPF & MP Act 1952 (EPF 12%+12%, EPS Pension 8.33% max ₹1250 limit, EDLI Insurance)' },
      { id: 'ss_2', name: 'Payment of Gratuity Act 1972 (15/26 x Wage x Years, 5 yrs service, ₹20 Lakh max cap)' },
      { id: 'ss_3', name: 'ESI Act 1948 & Maternity Benefit Act 1961/2017 (ESI 0.75%/3.25%, Maternity 26 wks leave, nursing breaks)' },
      { id: 'ss_4', name: 'Other Statutory Acts (Contract Labour 1970 50+ workers, Compensation Act 1923, Child Labour 1986, BOCW Act 1996, Unorganised Workers 2008)' },
      { id: 'ir_theory', name: 'IR Theory & Concepts (Wild-Cat strike, Yellow Dog contract, Audi Alteram Partem, Sidney & Beatrice Webb, NM Lokhande)' }
    ]
  },
  {
    id: 'sec_8_acc_audit_ins', title: 'viii. Principles of Accountancy, Auditing and Insurance', isCore: true,
    topics: [
      { id: 'acc_1', name: 'Accounting Fundamentals & AS-1 (Going Concern, Consistency, Accrual, Money Measurement, Matching)' },
      { id: 'acc_2', name: 'Journal Entry Recognition Trick (Outstanding=Liability/Credit, Prepaid=Asset/Debit, Accrued=Asset/Debit, Advance=Liability/Credit)' },
      { id: 'acc_3', name: 'Inventory Valuation FIFO vs LIFO (First-In-First-Out vs Last-In-First-Out worked logic)' },
      { id: 'acc_4', name: 'Account Classification & Golden Rules (Personal, Real, Nominal accounts)' },
      { id: 'acc_5', name: 'Trial Balance & Error Rectification (Compensating, Principle, Omission, Suspense Account)' },
      { id: 'acc_6', name: 'Depreciation Methods & Formula Bank (SLM vs WDV, Bad Debts formula, Gross Profit on Cost vs Sales, Operating Profit)' },
      { id: 'acc_7', name: 'Financial Ratios & Management (Current Ratio, Quick Ratio, Debt-Equity, ROI, EOQ formula √(2DS/H), Break-Even Point)' },
      { id: 'audit_1', name: 'Auditing Principles & Scope (Audit Strategy ➔ Audit Plan ➔ Audit Program, Vouching vs Verification, Audit File vs Documentation)' },
      { id: 'ins_1', name: 'Insurance Principles & SEBI (Indemnity contract, Average Clause claim formula, SEBI subrogation principle)' },
      { id: 'acc_spec', name: 'Specialized Accounting (Consignment abnormal loss, Joint Venture, Branch accounting Debtors system, Companies Act Schedule III)' }
    ]
  },
  {
    id: 'sec_9_current_events', title: 'ix. Current Events of National and International Importance', isCore: false,
    topics: [
      { id: 'curr_1', name: 'High-Priority Central Government Welfare Schemes (MUDRA, POSHAN, NISHTHA, StandUp India, SMILE, BioE3)' },
      { id: 'curr_2', name: 'International Financial Bodies & Trade (IMF Quota %, World Bank, WTO, Balance of Payments)' },
      { id: 'curr_3', name: 'Current Defence & Science Developments (AWACS, Drone Jamming, GPS Trilateration, AI & SSL updates)' },
      { id: 'curr_4', name: 'Current Economic Trends, Union Budget 2026 & PIB Highlights' }
    ]
  }
];

class APFCAppState {
  constructor() {
    this.formReleaseDate = new Date('2026-08-22T00:00:00');
    this.examDate = new Date('2026-12-20T09:30:00');
    const savedHours = localStorage.getItem('apfc_daily_target_hours');
    this.dailyTargetHours = savedHours ? parseInt(savedHours, 10) : 8;
    this.syllabusData = JSON.parse(localStorage.getItem('apfc_syllabus_progress') || '{}');
    this.studyLogs = JSON.parse(localStorage.getItem('apfc_study_logs') || '[]');
  }
  saveSyllabus() { localStorage.setItem('apfc_syllabus_progress', JSON.stringify(this.syllabusData)); }
  saveLogs() { localStorage.setItem('apfc_study_logs', JSON.stringify(this.studyLogs)); }
  saveSettings(h) { this.dailyTargetHours = parseInt(h, 10); localStorage.setItem('apfc_daily_target_hours', h); }
}

const appState = new APFCAppState();

document.addEventListener('DOMContentLoaded', () => {
  initTabs(); initCountdowns(); renderSyllabus(); renderDashboardWidget(); renderStudyLogs(); initPomodoroEngine(); initSettingsModal(); initQuickLogForm();
});

function initTabs() {
  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active'); document.getElementById(tab.getAttribute('data-tab')).classList.add('active');
    });
  });
}

function initCountdowns() { updateTimerDisplays(); setInterval(updateTimerDisplays, 1000); }
function updateTimerDisplays() {
  const now = new Date();
  const formDiff = appState.formReleaseDate - now;
  if (formDiff > 0) {
    document.getElementById('formDays').textContent = String(Math.floor(formDiff / (1000 * 60 * 60 * 24))).padStart(2, '0');
    document.getElementById('formHours').textContent = String(Math.floor((formDiff / (1000 * 60 * 60)) % 24)).padStart(2, '0');
    document.getElementById('formMinutes').textContent = String(Math.floor((formDiff / (1000 * 60)) % 60)).padStart(2, '0');
    document.getElementById('formSeconds').textContent = String(Math.floor((formDiff / 1000) % 60)).padStart(2, '0');
  } else { document.getElementById('formCountdown').innerHTML = `<div style="font-weight:700; color:#10b981;">FORM IS LIVE NOW!</div>`; }

  const examDiff = appState.examDate - now;
  if (examDiff > 0) {
    const eDays = Math.floor(examDiff / (1000 * 60 * 60 * 24));
    document.getElementById('examDays').textContent = String(eDays).padStart(3, '0');
    document.getElementById('examHours').textContent = String(Math.floor((examDiff / (1000 * 60 * 60)) % 24)).padStart(2, '0');
    document.getElementById('examMinutes').textContent = String(Math.floor((examDiff / (1000 * 60)) % 60)).padStart(2, '0');
    document.getElementById('examSeconds').textContent = String(Math.floor((examDiff / 1000) % 60)).padStart(2, '0');
    document.getElementById('estStudyHoursLeft').textContent = Math.floor(eDays * appState.dailyTargetHours).toLocaleString();
    document.getElementById('targetHoursRateDisplay').textContent = appState.dailyTargetHours;
    document.getElementById('currentDailyTargetDisplay').textContent = `${appState.dailyTargetHours} Hours/Day`;
  } else { document.getElementById('examCountdown').innerHTML = `<div style="font-weight:700; color:#ef4444;">EXAM DAY IS HERE!</div>`; }
}

function renderSyllabus() {
  const container = document.getElementById('syllabusContainer'); container.innerHTML = '';
  let totalTopics = 0, completedTopics = 0, revisedTopicsCount = 0, coreCompleted = 0;
  DEFAULT_SYLLABUS.forEach(module => {
    const card = document.createElement('div'); card.className = 'module-card';
    let modTotal = module.topics.length, modDone = 0;
    const topicItemsHTML = module.topics.map(topic => {
      totalTopics++;
      const p = appState.syllabusData[topic.id] || { concept: false, rev1: false, rev2: false, pyq: false };
      if (p.concept && (p.pyq || p.rev1)) modDone++;
      if (p.concept && p.rev1 && p.rev2) revisedTopicsCount++;
      return `
        <div class="topic-item">
          <div class="topic-name"><span>${topic.name}</span></div>
          <div class="topic-stages">
            <label class="stage-check"><input type="checkbox" data-topic="${topic.id}" data-stage="concept" ${p.concept ? 'checked' : ''}> Concepts</label>
            <label class="stage-check"><input type="checkbox" data-topic="${topic.id}" data-stage="rev1" ${p.rev1 ? 'checked' : ''}> Rev 1</label>
            <label class="stage-check"><input type="checkbox" data-topic="${topic.id}" data-stage="rev2" ${p.rev2 ? 'checked' : ''}> Rev 2</label>
            <label class="stage-check"><input type="checkbox" data-topic="${topic.id}" data-stage="pyq" ${p.pyq ? 'checked' : ''}> PYQs</label>
          </div>
        </div>
      `;
    }).join('');
    if (module.isCore && (modDone / modTotal >= 0.5)) coreCompleted++;
    completedTopics += (modDone === modTotal) ? modTotal : modDone;
    const percent = Math.round((modDone / modTotal) * 100);
    card.innerHTML = `<div class="module-card-header"><div class="module-title-area"><span class="module-badge ${module.isCore ? 'badge-core' : 'badge-std'}">${module.isCore ? 'High Weightage Core' : 'Official Notification Section'}</span><h3>${module.title}</h3></div><div style="font-weight:700; color:var(--accent-primary);">${percent}% (${modDone}/${modTotal})</div></div><div class="topic-list">${topicItemsHTML}</div>`;
    container.appendChild(card);
  });

  container.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
    checkbox.addEventListener('change', (e) => {
      const topicId = e.target.getAttribute('data-topic'); const stage = e.target.getAttribute('data-stage');
      if (!appState.syllabusData[topicId]) appState.syllabusData[topicId] = { concept: false, rev1: false, rev2: false, pyq: false };
      appState.syllabusData[topicId][stage] = e.target.checked;
      appState.saveSyllabus(); renderSyllabus(); renderDashboardWidget();
    });
  });

  const overallPercent = Math.round((completedTopics / totalTopics) * 100) || 0;
  document.getElementById('syllabusPercentDisplay').textContent = `${overallPercent}%`;
  document.getElementById('syllabusProgressFill').style.width = `${overallPercent}%`;
  document.getElementById('highWeightageProgressDisplay').textContent = `${coreCompleted} / 2 Core Modules`;
  document.getElementById('revisionCompletedDisplay').textContent = `${revisedTopicsCount} Topics`;
}

function renderDashboardWidget() {
  const widgetList = document.getElementById('subjectDashboardList'); widgetList.innerHTML = '';
  DEFAULT_SYLLABUS.filter(m => m.isCore).forEach(mod => {
    let modTotal = mod.topics.length, modDone = 0;
    mod.topics.forEach(t => { const p = appState.syllabusData[t.id]; if (p && p.concept && (p.pyq || p.rev1)) modDone++; });
    const percent = Math.round((modDone / modTotal) * 100);
    const item = document.createElement('div'); item.className = 'subject-progress-item';
    item.innerHTML = `<div class="subject-progress-meta"><strong>${mod.title}</strong><span>${percent}%</span></div><div class="subject-progress-bar"><div class="subject-progress-bar-fill" style="width: ${percent}%; background: var(--accent-primary);"></div></div>`;
    widgetList.appendChild(item);
  });
}

function initQuickLogForm() {
  document.getElementById('quickLogForm').addEventListener('submit', (e) => {
    e.preventDefault();
    appState.studyLogs.unshift({ id: Date.now(), date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }), subject: document.getElementById('logSubjectSelect').value, hours: parseFloat(document.getElementById('logHoursInput').value), note: document.getElementById('logTopicNote').value || 'Study Session' });
    appState.saveLogs(); renderStudyLogs(); alert('Study log saved!');
  });
}

function renderStudyLogs() {
  const tableBody = document.getElementById('logHistoryTableBody'); tableBody.innerHTML = '';
  let totalHours = 0, todayHours = 0;
  const todayStr = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  appState.studyLogs.forEach(log => {
    totalHours += log.hours; if (log.date === todayStr) todayHours += log.hours;
    const row = document.createElement('tr');
    row.innerHTML = `<td>${log.date}</td><td><strong>${log.subject}</strong></td><td><span class="badge badge-warning">${log.hours} hrs</span></td><td>${log.note}</td><td><button class="btn btn-secondary" onclick="deleteLogEntry(${log.id})"><i class="fa-solid fa-trash"></i></button></td>`;
    tableBody.appendChild(row);
  });
  document.getElementById('totalHoursStudiedDisplay').textContent = `${totalHours.toFixed(1)} hrs`;
  document.getElementById('todayHoursSubtext').textContent = `Today: ${todayHours.toFixed(1)} hrs`;
}

function deleteLogEntry(id) { appState.studyLogs = appState.studyLogs.filter(l => l.id !== id); appState.saveLogs(); renderStudyLogs(); }

/* ==========================================================================
   HIGH-PRECISION BACKGROUND-PROOF POMODORO FOCUS TIMER ENGINE
   ========================================================================== */
let pomoTargetDuration = 50 * 60 * 1000;
let pomoEndTime = null;
let pomoRemainingSeconds = 50 * 60;
let pomoIsRunning = false;
let pomoWorker = null;

function initPomodoroEngine() {
  const workerBlob = new Blob([`
    let timer = null;
    self.onmessage = function(e) {
      if (e.data === 'start') {
        if (timer) clearInterval(timer);
        timer = setInterval(function() { self.postMessage('tick'); }, 500);
      } else if (e.data === 'stop') {
        if (timer) clearInterval(timer);
        timer = null;
      }
    };
  `], { type: 'application/javascript' });
  
  try {
    pomoWorker = new Worker(URL.createObjectURL(workerBlob));
    pomoWorker.onmessage = function(e) {
      if (e.data === 'tick' && pomoIsRunning) {
        updatePomoClockFromTimestamp();
      }
    };
  } catch (err) {}

  document.querySelectorAll('.pomo-mode-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.pomo-mode-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const mode = btn.getAttribute('data-mode');
      if (mode === 'work') pomoTargetDuration = 50 * 60 * 1000;
      else if (mode === 'shortBreak') pomoTargetDuration = 10 * 60 * 1000;
      else pomoTargetDuration = 20 * 60 * 1000;
      resetPomoTimer();
    });
  });

  document.getElementById('pomoStartBtn').addEventListener('click', startPomoTimer);
  document.getElementById('pomoPauseBtn').addEventListener('click', pausePomoTimer);
  document.getElementById('pomoResetBtn').addEventListener('click', resetPomoTimer);

  document.addEventListener('visibilitychange', () => {
    if (pomoIsRunning) updatePomoClockFromTimestamp();
  });
  window.addEventListener('focus', () => {
    if (pomoIsRunning) updatePomoClockFromTimestamp();
  });
}

function startPomoTimer() {
  if (Notification && Notification.permission !== 'granted') {
    Notification.requestPermission();
  }
  pomoIsRunning = true;
  pomoEndTime = Date.now() + (pomoRemainingSeconds * 1000);
  
  document.getElementById('pomoStartBtn').style.display = 'none';
  document.getElementById('pomoPauseBtn').style.display = 'inline-flex';
  document.getElementById('pomoStatusText').textContent = 'Focusing... (Running in Background)';
  document.getElementById('timerRing').style.borderColor = 'var(--accent-success)';

  if (pomoWorker) pomoWorker.postMessage('start');
}

function pausePomoTimer() {
  pomoIsRunning = false;
  document.getElementById('pomoStartBtn').style.display = 'inline-flex';
  document.getElementById('pomoPauseBtn').style.display = 'none';
  document.getElementById('pomoStatusText').textContent = 'Paused';
  document.getElementById('timerRing').style.borderColor = 'var(--accent-warning)';

  if (pomoWorker) pomoWorker.postMessage('stop');
}

function resetPomoTimer() {
  pausePomoTimer();
  pomoRemainingSeconds = Math.round(pomoTargetDuration / 1000);
  pomoEndTime = null;
  document.getElementById('pomoStatusText').textContent = 'Ready to Focus';
  document.getElementById('timerRing').style.borderColor = 'var(--accent-primary)';
  renderPomoTimeDisplay(pomoRemainingSeconds);
}

function updatePomoClockFromTimestamp() {
  if (!pomoEndTime) return;
  const now = Date.now();
  const diffMs = pomoEndTime - now;
  if (diffMs <= 0) {
    pomoRemainingSeconds = 0;
    renderPomoTimeDisplay(0);
    triggerPomoCompletionAlert();
  } else {
    pomoRemainingSeconds = Math.ceil(diffMs / 1000);
    renderPomoTimeDisplay(pomoRemainingSeconds);
  }
}

function renderPomoTimeDisplay(sec) {
  const mins = Math.floor(sec / 60);
  const secs = sec % 60;
  const formattedMins = String(mins).padStart(2, '0');
  const formattedSecs = String(secs).padStart(2, '0');

  document.getElementById('pomoMinutes').textContent = formattedMins;
  document.getElementById('pomoSeconds').textContent = formattedSecs;

  if (pomoIsRunning) {
    document.title = `(${formattedMins}:${formattedSecs}) UPSC APFC Focus Timer`;
  } else {
    document.title = 'UPSC APFC / EPFO Official 9-Section Exam & Study Dashboard';
  }
}

function triggerPomoCompletionAlert() {
  pausePomoTimer();
  document.getElementById('pomoStatusText').textContent = '🎉 Session Completed!';
  document.getElementById('timerRing').style.borderColor = 'var(--accent-success)';
  
  try {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, audioCtx.currentTime);
    osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.3);
    gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 1.2);
  } catch (err) {}

  if (Notification && Notification.permission === 'granted') {
    new Notification('🎯 Focus Session Completed!', {
      body: 'Great job! Take a short break or log your completed study hours.',
      icon: 'https://cdn-icons-png.flaticon.com/512/2991/2991106.png'
    });
  } else {
    alert('🎉 Focus Session Completed! Great job!');
  }
}

function initSettingsModal() {
  const modal = document.getElementById('settingsModal');
  const select = document.getElementById('targetHoursSelect');
  select.value = String(appState.dailyTargetHours);

  const badgeBtn = document.getElementById('dailyHoursBadgeBtn');
  if (badgeBtn) badgeBtn.addEventListener('click', () => modal.classList.add('active'));
  document.getElementById('settingsBtn').addEventListener('click', () => modal.classList.add('active'));
  document.getElementById('closeSettingsBtn').addEventListener('click', () => modal.classList.remove('active'));

  document.querySelectorAll('.hour-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('.hour-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      select.value = pill.getAttribute('data-hrs');
    });
  });

  document.getElementById('saveSettingsBtn').addEventListener('click', () => {
    appState.saveSettings(select.value);
    updateTimerDisplays();
    modal.classList.remove('active');
  });
}
